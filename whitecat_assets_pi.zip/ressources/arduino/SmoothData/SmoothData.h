/************************************************************************************************************
 * SmoothData.h -
 Christoph Guillermet
 http://le-chat-noir-numerique.fr
 22/04/2015
 ************************************************************************************************************/

#ifndef SmoothData_h
#define SmoothData_h


class SmoothData {
  public:
    SmoothData (int Pin, int samples, int tolerance);


    void acquire(); //simple aquisition depuis la PIN
    void set_value(int value);//pour passer une donn�e � damperiser, sans lecture de Pins
    void resample();//aquisition en rafale pour extraire une moyenne, depuis la PIN
    void damper();//traitement de la donn�e en damper

    //damper specifique
    void set_damper_decay(float value);
    void set_damper_mode(int mode);
    void set_damper_blocking_mode(bool state);
    void acquire_damper_decay(int from_Pin);
    int getdmxvalue_dampered();
    float getvalue_dampered();
    //conversion en dmx
    int getdmxvalue();//renvoi de la valeur en dmx
    void setmaprange(int pied, int maxi);//d�finition du pied et du maxi pour convertir  des 1024 pas en 255 pas


  private:
    int _Pin;
    int _samples;//nombre d'�chantillons
    int _tol;//tol�rance
    unsigned int _pied;//pied du map 0-1023 (capteur)
    unsigned int _maxi;//max du map 0-1024 (capteur)

    //resample
    int _raw;//donn�es aquise du capteur
    int _previous_raw;//pr�c�dente donn�e
    int _index;//index
    int _sum;//somme � diviser par nb sample
    int _data_val;//valeur du capteur apr�s process

    //damper
    bool _damper_do_calculation;
    bool _damper_blocking_mode;//sortie de la main bloque la donn�e au niveau
    int _damper_mode;//0 default , 1 montee plus rapide, descente plus lente
    int _dampered_data;
    float _damper_decay_constant;
    float _damper_vel;
    float _damper_dt;
    float _damper_val; //value
    float _damper_target_val;
    float _damper_previous_target;
    float _damper_accel;

};

#endif

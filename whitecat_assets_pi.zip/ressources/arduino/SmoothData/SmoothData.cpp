#include <Arduino.h>
#include <SmoothData.h>

SmoothData::SmoothData(int Pin, int samples, int tolerance)
{
    _Pin=Pin;
    _samples=samples;
    _tol=tolerance/100;
    _pied=0;
    _maxi=1023;

    //damper
    _damper_do_calculation=0;
    _damper_mode=0;
    _damper_decay_constant = 0.6;
    _damper_vel = 0.1;
    _damper_dt = 0.1;
    _damper_val = 0.0;
    _damper_target_val = 0.0;
    _damper_previous_target=0.0;
}

////////////////////////////////////////////////////
void SmoothData::acquire()
{
_raw=analogRead(_Pin);
}

void  SmoothData::set_value(int value)
{
    _data_val=value;
    if(_data_val<_pied) _data_val=_pied;
    else if(_data_val>_maxi) _data_val=_maxi;
}

void SmoothData::resample()
{
    _index=0;
    _sum=0;
    for (int i=0; i<_samples; i++)
        {
        _raw=analogRead(_Pin);
        if(   _raw > (_previous_raw+((_previous_raw/100)*_tol))
           || _raw < (_previous_raw+((_previous_raw/100)*_tol)) )

          {
            _sum=_sum+_raw;
            _index++;
          }
        }
    _data_val=_sum/_index;
    if(_data_val<_pied) _data_val=_pied;
    else if(_data_val>_maxi) _data_val=_maxi;
}

////////////////////////////////////////////////////
void SmoothData::set_damper_decay(float value)
{
 _damper_decay_constant=value;
 if (_damper_decay_constant<.1) _damper_decay_constant=.1;
}

void  SmoothData::acquire_damper_decay(int from_Pin)
{
float tmp_val=analogRead(from_Pin);
tmp_val=map(tmp_val,0,1023,0,255);
_damper_decay_constant=tmp_val/255;
if (_damper_decay_constant<.1) _damper_decay_constant=.1;
}


void SmoothData::set_damper_mode(int mode)
{
    _damper_mode=mode;
}


void SmoothData::set_damper_blocking_mode(bool state)
{
    _damper_blocking_mode=state;
}

void SmoothData::damper()
{
_damper_previous_target=_damper_target_val;

float tmp=map(_data_val,_pied,_maxi,0,255);
_damper_target_val=tmp/255;



switch(_damper_blocking_mode)
    {
    case 0:
    _damper_do_calculation=1;
    break;
    case 1://no change of data = no calculation
    _damper_do_calculation=0;
    if(tmp!=_damper_previous_target) {_damper_do_calculation=1;}
    break;
    }

if(_damper_do_calculation==1)
{
    switch (_damper_mode)
    {
    case 1://elastic effect
    _damper_accel = (_damper_target_val - _damper_val) * 1 - _damper_vel *  _damper_decay_constant;
    _damper_vel += _damper_accel * _damper_dt;
    _damper_val += _damper_vel * _damper_dt;
    break;
    case 2:
    _damper_vel = (_damper_target_val - _damper_val) * _damper_decay_constant;
    _damper_val += _damper_vel * _damper_dt;
    break;
    default://in out egaux
    _damper_vel= (_damper_target_val-_damper_val)* _damper_decay_constant;
    _damper_val+=(_damper_vel*_damper_dt)* _damper_decay_constant;
    break;
    }
    if(_damper_val<0.0){_damper_val=0.0; _damper_do_calculation=0;}
    else if(_damper_val>1.0){_damper_val=1.0; _damper_do_calculation=0;}
}


_dampered_data=_damper_val*255;
}

float SmoothData::getvalue_dampered()
{
     return(_damper_val);
}

int SmoothData::getdmxvalue_dampered()
{
    return(_dampered_data);
}

////////////////////////////////////////////////////
int SmoothData::getdmxvalue()
{
int val=map(_data_val,_pied,_maxi,0,255);
return val;
}



void SmoothData::setmaprange(int pied, int maxi)//calibrage et threshold du transfert 0-1023 vers 0-255
{
_pied=pied;
_maxi=maxi;
}

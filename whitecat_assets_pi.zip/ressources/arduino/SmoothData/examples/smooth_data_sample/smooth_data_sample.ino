
#include "SmoothData.h"


SmoothData SHARP_1(A0, 20, 3); 

void setup()
{
 
  SHARP_1.setmaprange(100,630);

  SHARP_1.set_damper_mode(0);
  
  //SHARP_1.set_damper_decay(0.6);//reglage en fixe

  //SHARP_1.set_damper_blocking_mode(0);//bloque le signal si pas de changement, ex sortie de main

 
}

/////////////////////////////////////////////////////////////////
void loop()
{
 
SHARP_1.resample(); SHARP_1.damper();
float val=SHARP_1.getvalue_dampered();//valeur dampée
}


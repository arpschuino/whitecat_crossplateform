#include <Ports.h>
#include <RF12.h>


void setup () {

   //frequence 
   TCCR0B = TCCR0B & 0b11111000 | 001;
   //Modifie le fréquence pwm : à activer si la lampe "chante"
  
   rf12_initialize(2, RF12_868MHZ, 212);
    pinMode (4, OUTPUT);
    pinMode (5, OUTPUT);
    pinMode (6, OUTPUT);
    pinMode (7, OUTPUT);
    pinMode (14, OUTPUT);
    pinMode (15, OUTPUT);
    pinMode (16, OUTPUT);
    pinMode (17, OUTPUT);
}

void loop () {
    if (rf12_recvDone() && rf12_crc == 0) 
    {
       
      //reception en int / 4 char headers, circuit par 2
    //Jeenode P1
    analogWrite  (4, rf12_data[2]);  //D (n° de port du jeeNode, n° d'envoi depuis WCat)
    //analogWrite(14, rf12_data[3]);   //A
    //Jeenode P2
    analogWrite (5, rf12_data[4]);  //D (n° de port du jeeNode, n° d'envoi depuis WCat)
    //analogWrite(15, rf12_data[5]);   //A
    //Jeenode P2
    analogWrite (6, rf12_data[6]);  //D (n° de port du jeeNode, n° d'envoi depuis WCat)
    //analogWrite(16, rf12_data[7]);   //A
    //Jeenode P4
    analogWrite (7, rf12_data[8]);  //D(n° de port du jeeNode, n° d'envoi depuis WCat)
    //analogWrite(17, rf12_data[9]);   //A
 
   }
}

//dernière mise à jour: 
//21 avril 2015 pour UNO sous logiciel ARDUINO 1.63
//Ce sketch est conçu pour fonctionner avec WhiteCat Lighting Board 
//à partir de la version 0.8.7 !
//pour les versions précédentes de WhiteCat, utiliser whitecat_arduino_v1_6_old_script
//site: http://www.le-chat-noir-numerique.fr


//chaine des ordres venant de whitecat
#define maxLength 127+3 //definition digital_limit dans whitecat. 
//un train de 127 data max (on off + analog) + 3 pour identifiant WhiteCat 
String inString = String(maxLength);   
   


//definitions paramètres com:
const int BAUDRATE=14400;
boolean send_data_to_whitecat=1;

//définitions du nombre de capteurs ( doit concorder aussi dans whitecat -> arduino cfg)
const int NBR_ANALOG=5;
const int NBR_DIGITAL=13;
//création d'un tableau de définition pour les I/O 
boolean digital_is_output[NBR_DIGITAL];
boolean allow_analog_read[NBR_ANALOG];
boolean allow_pwm_write[NBR_DIGITAL];
////////////////////////////////////////////////////
//tableaux de stockage des valeurs reçues en input
byte buffer_analog[NBR_ANALOG];
byte buffer_digital[NBR_DIGITAL];
byte valeur_pwm[NBR_DIGITAL];

/////////////////////////////////////////////////////////////////
void setup()
{
  Serial.begin(BAUDRATE);
  inString = "";      // remet le buffer à 0

  // initialisation des pin digitals en entrée (haute impédance...)
  for (int i =2; i<NBR_DIGITAL; i++){
    digital_is_output[i]=0;
    pinMode(i,INPUT);    
    allow_pwm_write[i]=0;
  }

  ////////////////////////////////////////////////////////////////////////////////
  // a personnaliser en fonction de l'utilisation de l'arduino


  digital_is_output[3]=1;
  allow_pwm_write[3]=1;
  
  
  digital_is_output[4]=1;
  allow_pwm_write[4]=0;
  
    digital_is_output[5]=1;
  allow_pwm_write[5]=1;
  

  
  digital_is_output[9]=1;
  allow_pwm_write[9]=0;


  digital_is_output[10]=1;
  allow_pwm_write[10]=1;
  digital_is_output[11]=1;
  allow_pwm_write[11]=1;


/*autorisation de lecture des analogues. Si vous ne définnissez pas =1 l'analogue ne
   sera pas envoyé à WhiteCat*/
allow_analog_read[0]=1;
allow_analog_read[1]=1;


 //INITIALISATION DES ON/OFF sur la carte
 for(int i=2; i<NBR_DIGITAL; i++)
 {
   if(digital_is_output[i]==1)
   {pinMode(i,OUTPUT);}
  }
}
/////////////////////////////////////////////////////////////////
void loop()
{
  while(Serial.available() > 0) 
  {
  char inChar=Serial.read(); // lire caractere
     if(inChar!='\0') // un caractere nul marque la fin d'un ordre...
     {   
         if (inString.length() <maxLength)
         {inString+=inChar;} 
         else
         {inString ="";} 
      } 
    else // reçu 0, fin d'un ordre, on décode
      {
      if (inString.length() >= 3)
           {   
  
            read_order();
            inString = "";  
            break;
            }
      else {  inString = "";  }
      }  
  }
}
/////////////////////////////////////////////////////////////
void read_order()
{
// les trois premiers caractères déterminent l'ordre...
  String WCcde = inString.substring(0,3);    // commande whitecat
  if (WCcde == "SD/"){arduino_to_whitecat();}
  if(WCcde == "DO/"){whitecat_to_arduino();} 
  else if(WCcde != "DO/" && WCcde !="SD/")
  {inString="";}//nettoyage de la chaine d'ordre
}
///////////////////////////////////////////////////////////////////////
void whitecat_to_arduino()
{
  
  for(int i=2; i<NBR_DIGITAL; i++)//2 because TX RX
  {
   if(digital_is_output[i]==1)
   {    
    switch(allow_pwm_write[i])
    {
     case 0://on off
      if(inString[i+3]<64)
      {digitalWrite(i,LOW);} 
      else 
      {digitalWrite(i,HIGH);}
      break;
      case 1://PWM
      valeur_pwm[i]=byte(inString[i+3]);  
      analogWrite(i,valeur_pwm[i]-1);
      break;
    }  
    }
  }

}
/////////////////////////////////////////////////////////////////////
void arduino_to_whitecat()
{
 
int size_of_buf=NBR_DIGITAL+NBR_ANALOG;
char buffer_to_send[size_of_buf];
for(int i=0;i<size_of_buf;i++)
{
buffer_to_send[i]=1;//eviter le caractere NULL
}
int temp_val=0;

  //digitales///////////////////
  if(send_data_to_whitecat==1)
  {
  for(int i=2;i<NBR_DIGITAL;i++)//on zappe les états de TX RX en pins 0 et 1
  {
    if(digital_is_output[i]==0 && allow_pwm_write[i]==0)
    {
     temp_val=digitalRead(i); 
     if(temp_val==0){ buffer_to_send[i]= 32;}
     else buffer_to_send[i]= 127;
    }
  }
  
  for(int i=0;i<NBR_ANALOG;i++)
  {
    if(allow_analog_read[i]==1)//si on autorise la lecture de cet analog
    {
      temp_val=analogRead(i); 
      buffer_to_send[i+NBR_DIGITAL]=byte(temp_val/4);
      if(buffer_to_send[i] == 0)buffer_to_send[i]=1;  
    }
  }
  Serial.print("WC/");
  Serial.write(buffer_to_send,size_of_buf);
  Serial.println(""); 
  } 
}
/////////////////////////////////////////////////////////////////////////





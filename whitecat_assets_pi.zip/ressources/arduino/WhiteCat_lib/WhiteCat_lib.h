/************************************************************************************************************
 WhiteCat_lib.h - librairie de communication s�rie arduino avec le logiciel WhiteCat http://le-chat-noir-numerique.fr
 MAJ 24/06/2015
 This library only works from version 0.8.7, with Arduino 1.6.5
 christoph guillermet / karistouf@yahoo.fr /
 ************************************************************************************************************/

#ifndef WhiteCat_lib_h
#define WhiteCat_lib_h


#define Input 0
#define Output 1
#define Off 0
#define On 1


//array position for jeenode array, different from classical array
//used for init of input output and pwm positions, this to avoid several
//troubles with correspondance of pins (arduino pin vs jeenode pin)
//this jeenode array is sended to jeelink
#define Jeenode_P1_D 0
#define Jeenode_P1_A 1
#define Jeenode_P2_D 2
#define Jeenode_P2_A 3
#define Jeenode_P3_D 4
#define Jeenode_P3_A 5
#define Jeenode_P4_D 6
#define Jeenode_P4_A 7

//rerouting for writing on correct Pin (arduino adress)
#define Jee_P1_D 4
#define Jee_P1_A 14
#define Jee_P2_D 5
#define Jee_P2_A 15
#define Jee_P3_D 6
#define Jee_P3_A 16
#define Jee_P4_D 7
#define Jee_P4_A 17

#include <Arduino.h>

//if you want to use damper and resample functions uncomment and replace
//do the same for whitecat_lib.cpp
/*
const int MAX_Nbr__Digital=36;
const int MAX_Nbr__Analog=12;//soucis de m�moire � cause damper
*/
const int MAX_Nbr__Digital=64;
const int MAX_Nbr__Analog=36;//soucis de m�moire � cause damper


class WhiteCat {
  public:
    WhiteCat();

    void Init_Com(int Baudrate, int Nbr_Digital, int Nbr_Analog);
    void set_io_mode(int Pin, bool mode);
    void set_pwm(int Pin, bool mode);


    void serial_receive_and_do_orders();

    void _read_inputs_on_pins();//reading input on off and analog
    int _read_analog(int Pin);//returns value of analog readen
    boolean _read_digital(int Pin);//returns value of digital readen

    void send_data_to_whitecat();

    //////TEMPORARY ARRAY TO TRANSMIT DATA TO OTHER PROTOCOLS//////////////
    int buffer_state_to_send(int ord);//returns the complete buffer to send
    //if needed by other hardware like jeenodes
    int buffer_size_to_send();//return size of the array

    ///////AVOIDING HARDWARE PERTURBATIONS/////////////////////
    void set_arduino_pin_writing(bool mode);

    ///////JEENODES///////////////////////////////////////////
    void set_jeenode_id(int id);
    void set_jeenode_frequency(int mode);//RF12_433MHZ, RF12_868MHZ, RF12_915MHZ
    void set_jeenode_group(int grp);
    void set_send_jeenode(bool mode);
    void set_receive_jeenode(bool mode);
    void set_i_m_a_jeenode(bool mode);
    void jeelink_send_to_jeenode();//emitter send the jeenode array
    void jeenode_receive_data();
    void jeenode_receive_data_and_write_pins();//reiver write on pins the jeenode array
    void set_jeenode_read_analog_input(bool mode);
    void set_jeenode_read_digital_input(bool mode);
    void send_data_to_jeelink();
    void jeelink_receive_data_from_jeenode();
    //void jeelink_receive_data_from_specific_jeenode(int ExpectedID);
    int  jeelink_get_received_analog_data(int ord);//get a data
    void jeelink_get_all_received_analog_data();//copy all analog data
    int  jeelink_get_received_digital_data(int ord);//buttons input
    void jeelink_get_all_received_digital_data();//copy all analog data
    ////FILTERING////////////////////////////////////////
/*  void do_resample_for_analog_input(int ord,bool mode);
    void do_damper_for_analog_input(int ord,bool mode);

    void resample_params(int ord,int resample_rate,int tolerance);
    void damper_params(int ord,float decay_fac,bool blocking, int type);
    void set_min_max(int ord, int min_data,int max_data);
*/
    ////CHEATING DATA/////////////////////////////////////
    bool get_digital_input_state(int ord);
    void set_digital_input_state(int ord, bool state);
    /*int get_analog_input_state(int ord);*/
    int get_analog_input_raw_state(int ord);
    void set_analog_input_state(int ord, int state);


  private:

    int _Baudrate;
    char _buffer_to_send[MAX_Nbr__Digital+MAX_Nbr__Analog];
    char _buffer_received[MAX_Nbr__Digital+MAX_Nbr__Analog];
    int _Nbr_Digital;//user defined
    int _Nbr_Analog;//user defined

    bool _allow_pin_writing=1;//direct writing on pins, or not
    //needed for jeenodes and other hardwares using arduino pins

    bool _use_jeenode_send=0;
    bool _use_jeenode_receive=0;
    bool _i_m_a_jeenode=0;
    int _jeenode_id=1;//id of the emitter is 1
    int _jeenode_group=212;//default group
    int _jeenode_frequency=2;//RF12_868MHZ

    boolean _digital_is_output[MAX_Nbr__Digital];
    boolean _allow_pwm_write[MAX_Nbr__Digital];
    byte _buffer_digital[MAX_Nbr__Digital];
    byte _valeur_pwm[MAX_Nbr__Digital];
    byte _buffer_analog[MAX_Nbr__Analog];

    boolean  _buffer_state_dig[MAX_Nbr__Digital];
    boolean _DO_SEND_DATA_TO_WHITECAT=0;


    boolean _reading_analog_from_jeenode=0;
    boolean _reading_digital_from_jeenode=0;


    byte  _data_from_jeenode[MAX_Nbr__Digital];

    int _raw_data[MAX_Nbr__Analog];
    int _raw;//donn�es aquise du capteur
 /*
    //resample
    boolean _do_resample_analog_input[MAX_Nbr__Analog];

    int _samples[MAX_Nbr__Analog];//nombre d'�chantillons
    int _tol[MAX_Nbr__Analog];//tol�rance
    unsigned int _pied[MAX_Nbr__Analog];//pied du map 0-1023 (capteur)
    unsigned int _maxi[MAX_Nbr__Analog];//max du map 0-1024 (capteur)


    int _raw;//donn�es aquise du capteur
    int _previous_raw;//pr�c�dente donn�e
    int _index;//index
    int _sum;//somme � diviser par nb sample
    int _data_val[MAX_Nbr__Analog];//valeur du capteur apr�s process

    //damper
    boolean _do_damper_analog_input[MAX_Nbr__Analog];

    bool _damper_do_calculation[MAX_Nbr__Analog];
    bool _damper_blocking_mode[MAX_Nbr__Analog];//sortie de la main bloque la donn�e au niveau
    int _damper_mode[MAX_Nbr__Analog];//0 default , 1 montee plus rapide, descente plus lente
    int _dampered_data[MAX_Nbr__Analog];
    float _damper_decay_constant[MAX_Nbr__Analog];
    float _damper_vel[MAX_Nbr__Analog];
    float _damper_dt;
    float _damper_val[MAX_Nbr__Analog]; //value
    float _damper_target_val[MAX_Nbr__Analog];
    float _damper_previous_target[MAX_Nbr__Analog];
    float _damper_accel[MAX_Nbr__Analog];

*/
};

#endif

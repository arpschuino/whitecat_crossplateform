/*Dernière mise à jour: 27 avril 2015, par Christoph Guillermet

Ce sketch est conçu pour fonctionner avec WhiteCat Lighting Board
pour carte arduino sous logiciel ARDUINO 1.63

Il montre comment configurer l'arduino pour recevoir des données
des entrées analogiques et les filtrer.

Attention, il faut avoir décommenté la librairie (fichiers Whitecat_lib.cpp et Whitecat_lib.h
pour que les fonctions de dampering fonctionnent !

Le problème des capteurs c'est que la mesure peut varier en permanence. 
Par exemple avec un capteur infra rouge ou une cellule photo électrique.

Pour régler ce problème de stabilité du signal, il y a deux
fonctions utilisables dans la librairie whitecat: 
-resample qui va prendre un certain nombre de samples  et en
restituer la moyenne
-damper qui va amortir la donnée, rajoutant une latence et un 
effet hydrolique, donnant un effet moins linéaire sur les entrées sorties

D'autre part des fonctions de filtrages de passe bas et écrétage
sont utilisables avec la fonction set_min_max. 
set_min_max ne fonctionne qu'avec resample ou damper.

La configuration dans CFG MENU / Arduino doit correspondre.

télécharger whitecat: http://www.le-chat-noir-numerique.fr
forum: http://www.le-chat-noir-numerique.fr/forums
*/
#include <JeeLib.h>
#include <SoftPWM.h>
#include <WhiteCat_lib.h>

WhiteCat Wcat;


/////////////////////////////////////////////////////////////////
void setup()
{  
Wcat.Init_Com(14400,13,5);

//Analog configuration
//Pin 0
Wcat.set_min_max(0,100,630);//AnalogNumber, Min, Max
Wcat.do_resample_for_analog_input(0,On);//AnalogNumber, OnOff
Wcat.resample_params(0,20,1);//Analog Number, Nb Samples, Threshold difference

Wcat.do_damper_for_analog_input(0,On);//AnalogNumber, OnOff
Wcat.damper_params(0,0.9,Off,0);//AnalogNumber, DamperFactor, BlockingMode, DamperingMode
}

/////////////////////////////////////////////////////////////////
void loop()
{
Wcat.serial_receive_and_do_orders();
Wcat.send_data_to_whitecat();
}




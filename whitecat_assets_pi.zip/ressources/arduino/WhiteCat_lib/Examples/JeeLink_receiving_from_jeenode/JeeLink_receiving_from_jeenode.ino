/*Dernière mise à jour: 28 avril 2015, par Christoph Guillermet

Ce sketch est conçu pour fonctionner avec WhiteCat Lighting Board
pour cartes arduino JEENODE sous logiciel ARDUINO 1.63
Ces cartes travaillent en radio fréquence.

Ce script permet d'écrire dans whitecat tous les datas reçus d'un jeenode
par le jeelink.

Wcat 2= P1_D
Wcat 3= P1_A
Wcat 4= P2_D
Wcat 5= P2_A
Wcat 6= P3_D
Wcat 7= P3_A
Wcat 8= P4_D
Wcat 9= P4_A

télécharger whitecat: http://www.le-chat-noir-numerique.fr
forum: http://www.le-chat-noir-numerique.fr/forums
cartes jeenodes: http://jeelabs.com/

*/
#include <JeeLib.h>
#include <SoftPWM.h>
#include <WhiteCat_lib.h>

WhiteCat Wcat;

/////////////////////////////////////////////////////////////////
void setup()
{  
/*évite éventuellement d'écrire sur les IO et donc 
de casser des fonctions hardware tierces*/
Wcat.set_arduino_pin_writing(Off);

Wcat.set_jeenode_id(1);//l'identifiant du/des récepteurs doit être différent
Wcat.set_jeenode_frequency(RF12_868MHZ);//la bande utilisée doit être la même
Wcat.set_jeenode_group(212);//le groupe doit être le même

Wcat.set_receive_jeenode(On);//doit être activé AVANT Init_Com

Wcat.Init_Com(14400,13,5);//doit correspondre à la config whitecat dans cfg_arduino
}

/////////////////////////////////////////////////////////////////
void loop()
{
Wcat.serial_receive_and_do_orders();//receive whitecat thruth serial
Wcat.jeelink_receive_data_from_jeenode();//receive data from jeenode
Wcat.jeelink_get_all_received_digital_data();//receive digital only
Wcat.jeelink_get_all_received_analog_data();//receive analog only
Wcat.send_data_to_whitecat();//send to whitecat data
}


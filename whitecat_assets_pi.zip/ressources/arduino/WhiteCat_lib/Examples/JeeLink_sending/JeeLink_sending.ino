/*Dernière mise à jour: 28 avril 2015, par Christoph Guillermet

Ce sketch est conçu pour fonctionner avec WhiteCat Lighting Board
pour cartes arduino JEENODE sous logiciel ARDUINO 1.63
Ces cartes travaillent en radio fréquence.

Ce script permet d' envoyer les datas émis par whitecat 
vers un réseau jeenode 212 depuis un jeelink.

Vous pouvez directement utiliser le tableau d'IO sans penser qui fait
du pwn, et qui est on/off. en effet le jeenode gradue en softPWM.
Donc les sorties 2->à 13 peuvent être toutes utilisées en PWM.

télécharger whitecat: http://www.le-chat-noir-numerique.fr
forum: http://www.le-chat-noir-numerique.fr/forums
cartes jeenodes: http://jeelabs.com/

*/
#include <JeeLib.h>
#include <SoftPWM.h>
#include <WhiteCat_lib.h>

WhiteCat Wcat;

/////////////////////////////////////////////////////////////////
void setup()
{  
/*évite éventuellement d'écrire sur les IO et donc 
de casser des fonctions hardware tierces*/
Wcat.set_arduino_pin_writing(Off);

Wcat.set_jeenode_id(1);//l'identifiant du/des récepteurs doit être différent
Wcat.set_jeenode_frequency(RF12_868MHZ);//la bande utilisée doit être la même
Wcat.set_jeenode_group(212);//le groupe doit être le même
Wcat.set_send_jeenode(On);//doit être activé AVANT Init_Com

Wcat.Init_Com(14400,13,5);//doit correspondre à la config whitecat dans cfg_arduino
}

/////////////////////////////////////////////////////////////////
void loop()
{
Wcat.serial_receive_and_do_orders();
Wcat.jeelink_send_to_jeenode();
}


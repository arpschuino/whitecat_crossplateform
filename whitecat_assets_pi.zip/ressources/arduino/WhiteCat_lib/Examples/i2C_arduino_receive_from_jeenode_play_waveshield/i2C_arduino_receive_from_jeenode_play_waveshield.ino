/*Dernière mise à jour: 5 mai 2015, par Christoph Guillermet

Ce sketch est conçu pour fonctionner avec WhiteCat Lighting Board
pour cartes arduino JEENODE sous logiciel ARDUINO 1.63
Ces cartes travaillent en radio fréquence.

Ce script permet de recevoir dans l'arduino les datas émis par 
whitecat depuis un jeelink sur le réseau jeenode 212.
le jeenode retransmet un tableau de 8 données, en bus i2C vers une arduino.
il n'écrit pas sur les ports jeenode.

Petite particularité, les digitales sont utilisées ainsi:
Wcat 2=  // Adresse 0
Wcat 3=  // Adresse 1
Wcat 4=  // etc ect..

ATTENTION !!! POUR LE WAVE SHIELD, ET QUE LE CONTROLE DU VOLUME 
FONCTIONNE !!!!!
ALLER DANS WAVEHC.H et CHANGER: #define DVOLUME 0
par #define DVOLUME 1

télécharger whitecat: http://www.le-chat-noir-numerique.fr
forum: http://www.le-chat-noir-numerique.fr/forums
cartes jeenodes: http://jeelabs.com/
*/

///////////////CANAUX DEFINITION DES CIRCUITS//////////////////////////////////////////

#define canal_play_stop 0
#define canal_file 1
#define canal_volume 2
#define canal_seek 3



int threshold=10;//niveau de déclenchement play stop

bool play_state=0;
int previous_file=-1;
int file_to_play=0;
//////////////DEFINITION DES NOMS DE FICHIERS AUDIO/////////////////
///LES FICHIERS DOIVENT ETRE WAV MONO 16bits, 22050 Hz////////////////
char fichier_1[] = "bongo.wav"; 
char fichier_2[] = "water.wav"; 
char fichier_3[] = "harpA69.wav"; 
char fichier_4[] = "oud.wav"; 
char fichier_5[] = "koto.wav"; 
char fichier_6[] = "fofo.wav"; 
char fichier_7[] = "shekerra.wav"; 
char fichier_8[] = "tabla.wav"; 
char fichier_9[] = "dulcimer.wav"; 
char fichier_10[] = "jerome.wav"; 
///////////////COM I2C/////////////////////////////////////////////////////////////////

#include <Wire.h>

#define MAX_SENT_BYTES 8
byte i2c_data[MAX_SENT_BYTES];
byte previous_i2c_data[MAX_SENT_BYTES];

//jeenode SCL vers A5
//jeenode SDA vers A4

/////////////WAVE SHIELD///////////////////////////////////////////
#include "WaveUtil.h"
#include "WaveHC.h"

SdReader card;    // This object holds the information for the card
FatVolume vol;    // This holds the information for the partition on the card
FatReader root;   // This holds the information for the filesystem on the card
FatReader f;      // This holds the information for the file we're playing

WaveHC wave;      // This is the only wave (audio) object, since we will only play one at a time

///////////////////////////////////////////////////////////////////

void setup() {
  Serial.begin(9600);
  freeRam(); 

  initDACcontrol();
  initSDcard();
  initArrays();
  Wire.begin(4);        // join i2c bus (address optional for master)
  Wire.onReceive(receiveEvent);
  
  
}

void loop() 
{

if(i2c_data[canal_play_stop]>threshold && play_state==0)//&& previous_i2c_data[canal_play_stop]<=threshold)
{ 
Serial.println("PLAY!");
if(file_to_play!=previous_file || previous_i2c_data[canal_play_stop]<=threshold)
{
switch(file_to_play)
{
case 1:
load_file(fichier_1);
break;
case 2:
load_file(fichier_2);
break;
case 3:
load_file(fichier_3);
break;
case 4:
load_file(fichier_4);
break;
case 5:
load_file(fichier_5);
break;
case 6:
load_file(fichier_6);
break;
case 7:
load_file(fichier_7);
break;
case 8:
load_file(fichier_8);
break;
case 9:
load_file(fichier_9);
break;
case 10:
load_file(fichier_10);
break;
default:
break;
}
previous_file=file_to_play;
}

wave.play(); 
play_state=1;

}
if(i2c_data[canal_play_stop]<threshold && play_state==1)//&& previous_i2c_data[canal_play_stop]>=threshold)
{
Serial.println("STOP!");
if (wave.isplaying)   {wave.stop();}  
play_state=0;
}

if(i2c_data[canal_seek]>threshold && previous_i2c_data[canal_seek]<=threshold)
{ 
Serial.println("SEEK!");
wave.seek(0);
}

if(i2c_data[canal_volume]!=previous_i2c_data[canal_volume])
{
Serial.print("Volume: ");
int vl=map(i2c_data[canal_volume],0,255,10,0);//le DAC encaisse que 10 pas d'intensité sonore
Serial.print( vl,DEC);
Serial.println();
wave.volume=vl;
}

if(i2c_data[canal_file]!=previous_i2c_data[canal_file])
{
file_to_play=map(i2c_data[canal_file],0,255,1,10); //10 fichiers
Serial.print("File position: ");
Serial.print( file_to_play,DEC);
switch(file_to_play)
{
case 1:
Serial.println(fichier_1);
break;
case 2:
Serial.println(fichier_2);
break;
case 3:
Serial.println(fichier_3);
break;
case 4:
Serial.println(fichier_4);
break;
case 5:
Serial.println(fichier_5);
break;
case 6:
Serial.println(fichier_6);
break;
case 7:
Serial.println(fichier_7);
break;
case 8:
Serial.println(fichier_8);
break;
case 9:
Serial.println(fichier_9);
break;
case 10:
Serial.println(fichier_10);
break;
default:
break;
}
}

for(int i=0;i<MAX_SENT_BYTES ;i++)
{previous_i2c_data[i]=i2c_data[i];}
}



void receiveEvent(int bytesReceived)
{
byte index = 0;
while(Wire.available() > 0 && index <MAX_SENT_BYTES)
{
  i2c_data[index] = Wire.read();
  index++;
}
}

// Plays a full file from beginning to end with no pause.
void playcomplete(char *name) {
  // call our helper to find and play this name
  playfile(name);
  while (wave.isplaying) {
  // do nothing while its playing
  }
  // now its done playing
}

void playfile(char *name) {
  // see if the wave object is currently doing something
  if (wave.isplaying) {// already playing something, so stop it!
    wave.stop(); // stop it
  }
  // look in the root directory and open the file
  if (!f.open(root, name)) {
    putstring("Couldn't open file "); Serial.print(name); return;
  }
  // OK read the file and turn it into a wave object
  if (!wave.create(f)) {
    putstring_nl("Not a valid WAV"); return;
  }
  
  // ok time to play! start playback
  wave.play();
}

void load_file(char *name)
{
  // look in the root directory and open the file
  if (!f.open(root, name)) {
    putstring("Couldn't open file "); Serial.print(name); return;
  }
  // OK read the file and turn it into a wave object
  if (!wave.create(f)) {
    putstring_nl("Not a valid WAV"); return;
  }  
  if(play_state==1)
  {wave.play();}
}




// this handy function will return the number of bytes currently free in RAM, great for debugging!   
int freeRam(void)
{
  extern int  __bss_end; 
  extern int  *__brkval; 
  int free_memory; 
  if((int)__brkval == 0) {
    free_memory = ((int)&free_memory) - ((int)&__bss_end); 
  }
  else {
    free_memory = ((int)&free_memory) - ((int)__brkval); 
  }
  return free_memory; 
} 


void sdErrorCheck(void)
{
  if (!card.errorCode()) return;
  putstring("\n\rSD I/O error: ");
  Serial.print(card.errorCode(), HEX);
  putstring(", ");
  Serial.println(card.errorData(), HEX);
  while(1);
}

void initSDcard()
{
  //  if (!card.init(true)) { //play with 4 MHz spi if 8MHz isn't working for you
  if (!card.init()) {         //play with 8 MHz spi (default faster!)  
    putstring_nl("Card init. failed!");  // Something went wrong, lets print out why
    sdErrorCheck();
    while(1);                            // then 'halt' - do nothing!
  }
  
  // enable optimize read - some cards may timeout. Disable if you're having problems
  card.partialBlockRead(true);
 
// Now we will look for a FAT partition!
  uint8_t part;
  for (part = 0; part < 5; part++) {     // we have up to 5 slots to look in
    if (vol.init(card, part)) 
      break;                             // we found one, lets bail
  }
  if (part == 5) {                       // if we ended up not finding one  :(
    putstring_nl("No valid FAT partition!");
    sdErrorCheck();      // Something went wrong, lets print out why
    while(1);                            // then 'halt' - do nothing!
  }
  
  // Lets tell the user about what we found
  putstring("Using partition ");
  Serial.print(part, DEC);
  putstring(", type is FAT");
  Serial.println(vol.fatType(),DEC);     // FAT16 or FAT32?
  
  // Try to open the root directory
  if (!root.openRoot(vol)) {
  putstring_nl("Can't open root dir!"); // Something went wrong,
    while(1);                             // then 'halt' - do nothing!
  }
  
  // Whew! We got past the tough parts.
  putstring_nl("Ready!");
  
}

void initDACcontrol()
{
  // Set the output pins for the DAC control. This pins are defined in the library
  pinMode(2, OUTPUT);
  pinMode(3, OUTPUT);
  pinMode(4, OUTPUT);
  pinMode(5, OUTPUT);  
}

void initArrays()
{
for(int i=0;i<MAX_SENT_BYTES;i++)
{
i2c_data[i]=0;
previous_i2c_data[i]=0;
}
}

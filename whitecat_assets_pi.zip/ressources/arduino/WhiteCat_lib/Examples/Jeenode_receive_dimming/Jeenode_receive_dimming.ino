/*Dernière mise à jour: 5 mai 2015, par Christoph Guillermet

Ce sketch est conçu pour fonctionner avec WhiteCat Lighting Board
pour cartes arduino JEENODE sous logiciel ARDUINO 1.63
Ces cartes travaillent en radio fréquence.

Ce script permet de recevoir dans le jeenode les datas émis par 
whitecat depuis un jeelink sur le réseau jeenode 212.
Avec ce script vous pilotez en softPWM les 8 ports en output du jeenode.

Petite particularité, les digitales sont utilisées ainsi:
Wcat 2= P1_D
Wcat 3= P1_A
Wcat 4= P2_D
Wcat 5= P2_A
Wcat 6= P3_D
Wcat 7= P3_A
Wcat 8= P4_D
Wcat 9= P4_A

La librairie comprend en effet un reroutage des pins, de façon 
à ne pas perdre le temps avec n tableau de correspondances.

télécharger whitecat: http://www.le-chat-noir-numerique.fr
forum: http://www.le-chat-noir-numerique.fr/forums
cartes jeenodes: http://jeelabs.com/

*/
#include <JeeLib.h>
#include <SoftPWM.h>
#include <WhiteCat_lib.h>

WhiteCat Wcat;


void setup () {
  
    Wcat.set_jeenode_id(2);//l'identifiant du/des récepteurs doit être différent
    Wcat.set_jeenode_frequency(RF12_868MHZ);//la bande utilisée doit être la même
    Wcat.set_jeenode_group(212);//le groupe doit être le même
    Wcat.set_arduino_pin_writing(On);
    Wcat.set_i_m_a_jeenode(On);
    Wcat.set_receive_jeenode(On);//doit être activé AVANT Init_Com

    
    Wcat.Init_Com(14400,13,5);//init du jeenode inside
        
    Wcat.set_io_mode(Jeenode_P1_D,Output);
    Wcat.set_pwm(Jeenode_P1_D,On);
    
    Wcat.set_io_mode(Jeenode_P1_A,Output);
    Wcat.set_pwm(Jeenode_P1_A,On);
    
    Wcat.set_io_mode(Jeenode_P2_D,Output);    
    Wcat.set_pwm(Jeenode_P2_D,On);
    
    Wcat.set_io_mode(Jeenode_P2_A,Output);    
    Wcat.set_pwm(Jeenode_P2_A,On);
    
    Wcat.set_io_mode(Jeenode_P3_D,Output);
    Wcat.set_pwm(Jeenode_P3_D,On);
     
    Wcat.set_io_mode(Jeenode_P3_A,Output);
    Wcat.set_pwm(Jeenode_P3_A,On);
    
    Wcat.set_io_mode(Jeenode_P4_D,Output);
    Wcat.set_pwm(Jeenode_P4_D,On);
 
    Wcat.set_io_mode(Jeenode_P4_A,Output);
    Wcat.set_pwm(Jeenode_P4_A,On);  
   /*si la lampe "chante" utiliser:
   TCCR0B = TCCR0B & 0b11111000 | 001;
   */
  }

void loop () 
{
  Wcat.jeenode_receive_data_and_write_pins();
}

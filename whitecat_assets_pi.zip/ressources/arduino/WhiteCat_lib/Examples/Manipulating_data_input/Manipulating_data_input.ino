/*Dernière mise à jour: 27 avril 2015, par Christoph Guillermet

Ce sketch est conçu pour fonctionner avec WhiteCat Lighting Board
pour carte arduino sous logiciel ARDUINO 1.63

Il montre comment configurer l'arduino pour recevoir des données
des entrées analogiques, les filtrer et les remanipuler avant de 
les envoyer à whitecat.

Avant de lire ce code, regarder le script Analog_in_dampered.ino.

Ce script permet d'utiliser un potentiomètre en A0 et  un 
bouton branché en Pin 8.
Si le bouton branché en 8 est appuyé, l'entrée Analogique A1 
reçoit le niveau le A0 divisé par 2.

Avec ces manipulations de datas, vous pouvez donc rajouter des
fonctions supplémentaires à la bibliothèque WhiteCat_lib en augmentant 
votre nombre d'entrées analogiques de manière fictive 
(au lieu de 6 entrées, en faire 7 ou 8, ou 12, le max étant 18)
et y reportant le résultat de vos calculs.


La configuration dans CFG MENU / Arduino doit correspondre.

télécharger whitecat: http://www.le-chat-noir-numerique.fr
forum: http://www.le-chat-noir-numerique.fr/forums
*/
#include <JeeLib.h>
#include <SoftPWM.h>
#include <WhiteCat_lib.h>

WhiteCat Wcat;


/////////////////////////////////////////////////////////////////
void setup()
{  
Wcat.Init_Com(14400,13,5);

//Input bouton Pin 8
Wcat.set_io_mode(8,Input);
}

/////////////////////////////////////////////////////////////////
void loop()
{

Wcat.serial_receive_and_do_orders();

int data_in=Wcat.get_analog_input_state(0);

if(Wcat.get_digital_input_state(8)==1)//appuyé envoi du data à moité
  {
  Wcat.set_analog_input_state(1,data_in/2);
  }
  else //pas appuyé: le data normal
  {
  Wcat.set_analog_input_state(1,data_in);
  }

Wcat.send_data_to_whitecat();
}




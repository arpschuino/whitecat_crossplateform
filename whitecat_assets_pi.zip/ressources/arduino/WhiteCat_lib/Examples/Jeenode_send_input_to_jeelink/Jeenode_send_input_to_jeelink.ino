/*Dernière mise à jour: 2 juin 2015, par Christoph Guillermet

Ce sketch est conçu pour fonctionner avec WhiteCat Lighting Board
pour cartes arduino JEENODE sous logiciel ARDUINO 1.64
Ces cartes travaillent en radio fréquence.

Ce script permet d'émettre un capteur branché sur l'entrée analogique
du jeenode vers un jeelink sur le réseau jeenode 212.
Une led est rajoutée sur le jeenode, pour monitorer la donnée envoyée.

Le jeelink retransmettra dans whitecat les données reçues.

Petite particularité, les digitales sont utilisées ainsi:
Wcat 2= P1_D
Wcat 3= P1_A
Wcat 4= P2_D
Wcat 5= P2_A
Wcat 6= P3_D
Wcat 7= P3_A
Wcat 8= P4_D
Wcat 9= P4_A

La librairie comprend en effet un reroutage des pins, de façon 
à ne pas perdre le temps avec n tableau de correspondances.

télécharger whitecat: http://www.le-chat-noir-numerique.fr
forum: http://www.le-chat-noir-numerique.fr/forums
cartes jeenodes: http://jeelabs.com/

*/
#include <JeeLib.h>
#include <SoftPWM.h>
#include <WhiteCat_lib.h>

WhiteCat Wcat;


void setup () {
  
    Wcat.set_jeenode_id(2);//l'identifiant du/des récepteurs doit être différent
    Wcat.set_jeenode_frequency(RF12_868MHZ);//la bande utilisée doit être la même
    Wcat.set_jeenode_group(212);//le groupe doit être le même
    Wcat.set_i_m_a_jeenode(On);
    //re route les adresses - il y a une difference entre les pins arduino et les pins jeenode 
    Wcat.set_jeenode_read_analog_input(On);
    Wcat.set_jeenode_read_digital_input(On);
    
       
    Wcat.set_send_jeenode(On);//doit être activé AVANT Init_Com
    //permet l'emission vers le jeelink recepteur 
    
    
    Wcat.Init_Com(14400,13,5);//init du jeenode inside
    
    Wcat.set_io_mode(Jeenode_P1_D,Input);
    Wcat.set_io_mode(Jeenode_P2_D,Output);
    
}

void loop () 
{  

   Wcat._read_inputs_on_pins();
   bool val=Wcat.get_digital_input_state(Jeenode_P1_D);
   //monitoring the on off button from P1_D
   digitalWrite(Jee_P2_D,val); 
   //notice that for direct digitalwrite or analog write 
   //the name is NOT Jeenode_P2_D but Jee_P2_D
   //Jeenode_P2_D concerns position in the jee array and is not routing 
  
   Wcat.send_data_to_jeelink();
}

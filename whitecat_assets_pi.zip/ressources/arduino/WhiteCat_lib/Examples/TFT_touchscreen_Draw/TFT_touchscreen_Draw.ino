/*Dernière mise à jour: 24 mai 2015, par Christoph Guillermet

Ce sketch est conçu pour fonctionner avec WhiteCat Lighting Board
pour carte arduino sous logiciel ARDUINO 1.63
Il montre comment utiliser un écran TFTLCD Arduino shield de chez Adafruit
Il permet d'utiliser Draw en affectant les 4 entrées analogiques 
à Draw X1, Draw X2, Draw Y1, DrawY2 dans le CFG Arduino

La configuration dans CFG MENU / Arduino doit correspondre.

télécharger whitecat: http://www.le-chat-noir-numerique.fr
forum: http://www.le-chat-noir-numerique.fr/forums
*/

#include <Adafruit_GFX.h>    // Core graphics library
#include <Adafruit_TFTLCD.h> // Hardware-specific library
#include <TouchScreen.h>

#if defined(__SAM3X8E__)
    #undef __FlashStringHelper::F(string_literal)
    #define F(string_literal) string_literal
#endif

#ifndef USE_ADAFRUIT_SHIELD_PINOUT 
 #error "This sketch is intended for use with the TFT LCD Shield. Make sure that USE_ADAFRUIT_SHIELD_PINOUT is #defined in the Adafruit_TFTLCD.h library file."
#endif

// These are the pins for the shield!
#define YP A1  // must be an analog pin, use "An" notation!
#define XM A2  // must be an analog pin, use "An" notation!
#define YM 7   // can be a digital pin
#define XP 6   // can be a digital pin

#ifdef __SAM3X8E__
  #define TS_MINX 125
  #define TS_MINY 170
  #define TS_MAXX 880
  #define TS_MAXY 940
#else
  #define TS_MINX  150
  #define TS_MINY  120
  #define TS_MAXX  920
  #define TS_MAXY  940
#endif

// For better pressure precision, we need to know the resistance
// between X+ and X- Use any multimeter to read it
// For the one we're using, its 300 ohms across the X plate
TouchScreen ts = TouchScreen(XP, YP, XM, YM, 300);

#define LCD_CS A3
#define LCD_CD A2
#define LCD_WR A1
#define LCD_RD A0

// Assign human-readable names to some common 16-bit color values:
#define	BLACK   0x0000
#define	BLUE    0x001F
#define	RED     0xF800
#define	GREEN   0x07E0
#define CYAN    0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE   0xFFFF


Adafruit_TFTLCD tft;

#include <JeeLib.h>
#include <SoftPWM.h>
#include <WhiteCat_lib.h>

WhiteCat Wcat;



void setup(void) {
  Wcat.Init_Com(14400,13,5);
  tft.reset();

  uint16_t identifier = tft.readID();
  tft.begin(identifier);
  tft.fillScreen(BLACK);
  pinMode(13, OUTPUT);
  

}

#define MINPRESSURE 10
#define MAXPRESSURE 1000
#define PENRADIUS  30
int  x_screen_remaped, y_screen_remaped, previous_x_scr, previous_y_scr;

int x_whitecat, y_whitecat;
int x_whitecat_size=555;
int y_whitecat_size=430;

void loop()
{
Wcat.serial_receive_and_do_orders();
  TSPoint p = ts.getPoint();
  //pinMode(XP, OUTPUT);
  pinMode(XM, OUTPUT);
  pinMode(YP, OUTPUT);
  //pinMode(YM, OUTPUT);

  if (p.z > 0 && p.z < MAXPRESSURE) {
  previous_x_scr=x_screen_remaped;
  previous_y_scr=y_screen_remaped;
    // scale from 0->1023 to tft.width
    x_screen_remaped = map(p.x, TS_MINX, TS_MAXX, tft.width(), 0);
    y_screen_remaped = map(p.y, TS_MINY, TS_MAXY, tft.height(), 0);
    x_whitecat=  map(p.y, TS_MINX, TS_MAXX, x_whitecat_size, 0);
    y_whitecat=map(p.x, TS_MINY, TS_MAXY, 0, y_whitecat_size);
     
    if(x_whitecat<0){x_whitecat=0;}
    if(y_whitecat<0){y_whitecat=0;}
   // tft.fillScreen(BLACK);
   tft.drawRect(previous_x_scr-(PENRADIUS/2), previous_y_scr-(PENRADIUS/2),PENRADIUS,PENRADIUS, BLACK);
  
   tft.drawRect(x_screen_remaped-(PENRADIUS/2), y_screen_remaped-(PENRADIUS/2), PENRADIUS,PENRADIUS, WHITE);
   }
   
   
Wcat.serial_receive_and_do_orders();

if(x_whitecat<=255)
{
Wcat.set_analog_input_state(0,x_whitecat);
Wcat.set_analog_input_state(1,0);
}
if(x_whitecat>255)
{
Wcat.set_analog_input_state(0,x_whitecat);
Wcat.set_analog_input_state(1,x_whitecat-255);
}


if(y_whitecat<=255)
{
Wcat.set_analog_input_state(2,y_whitecat);
Wcat.set_analog_input_state(3,0);
}
if(y_whitecat>255)
{
Wcat.set_analog_input_state(2,y_whitecat);
Wcat.set_analog_input_state(3,y_whitecat-255);
}


Wcat.send_data_to_whitecat();

}


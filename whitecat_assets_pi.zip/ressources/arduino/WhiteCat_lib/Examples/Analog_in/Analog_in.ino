/*Dernière mise à jour: 27 avril 2015, par Christoph Guillermet

Ce sketch est conçu pour fonctionner avec WhiteCat Lighting Board
pour carte arduino sous logiciel ARDUINO 1.63
Il montre comment configurer l'arduino pour recevoir des données
des entrées analogiques (brancher des capteurs type potentiomètres,
infra-rouges, télémètres, cellules photo électriques, ...)

La configuration dans CFG MENU / Arduino doit correspondre.

télécharger whitecat: http://www.le-chat-noir-numerique.fr
forum: http://www.le-chat-noir-numerique.fr/forums
*/
#include <JeeLib.h>
#include <SoftPWM.h>
#include <WhiteCat_lib.h>

WhiteCat Wcat;


/////////////////////////////////////////////////////////////////
void setup()
{  
Wcat.Init_Com(14400,13,5);
}

/////////////////////////////////////////////////////////////////
void loop()
{
Wcat.serial_receive_and_do_orders();
Wcat.send_data_to_whitecat();
}




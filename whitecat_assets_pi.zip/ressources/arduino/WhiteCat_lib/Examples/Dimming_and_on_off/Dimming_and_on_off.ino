/*Dernière mise à jour: 27 avril 2015, par Christoph Guillermet

Ce sketch est conçu pour fonctionner avec WhiteCat Lighting Board
pour carte arduino sous logiciel ARDUINO 1.63
Il montre comment configurer l'arduino pour GRADUER 
en pwm la pin 3 et mettre en on off la pin 11 

La configuration dans CFG MENU / Arduino doit correspondre.

télécharger whitecat: http://www.le-chat-noir-numerique.fr
forum: http://www.le-chat-noir-numerique.fr/forums
*/
#include <JeeLib.h>
#include <SoftPWM.h>
#include <WhiteCat_lib.h>

WhiteCat Wcat;

/////////////////////////////////////////////////////////////////
void setup()
{  
//les paramètres doivent correspondre dans la fenêtre CFG MENU / Arduino
Wcat.Init_Com(14400,13,5);
//PWM 3
Wcat.set_io_mode(3,Output);
Wcat.set_pwm(3,On);
//PWM 11
Wcat.set_io_mode(11,Output);  //On off donc pas de fonction Wcat.set_pwm(11,Off);
}

/////////////////////////////////////////////////////////////////
void loop()
{
Wcat.serial_receive_and_do_orders();
}




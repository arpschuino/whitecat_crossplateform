//jeenode SCL vers A4
//jeenode SDA vers A4

int led_receive=7;
int led_control=13;
#include <Wire.h>

#define MAX_SENT_BYTES 8
byte i2c_data[MAX_SENT_BYTES];
int event=0;
bool state=1;

void setup() 
{ Serial.begin(9600);
  Wire.begin(4);        // join i2c bus (address optional for master)
  Wire.onReceive(receiveEvent);
  pinMode(led_control,OUTPUT);
  pinMode(led_receive,OUTPUT);
}

void loop() 
{
if( i2c_data[0]<64)
{digitalWrite(led_control,LOW);
}
else {
digitalWrite(led_control,HIGH);
}

analogWrite(6,i2c_data[6]);
}


void receiveEvent(int bytesReceived)
{
byte index = 0;
while(Wire.available() > 0 && index <MAX_SENT_BYTES)
{
   i2c_data[index] = Wire.read();
  index++;
}
}




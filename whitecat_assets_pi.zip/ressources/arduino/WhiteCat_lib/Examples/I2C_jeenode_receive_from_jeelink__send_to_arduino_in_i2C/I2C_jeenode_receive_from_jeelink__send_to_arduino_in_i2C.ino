
/*Dernière mise à jour: 5 mai 2015, par Christoph Guillermet

Ce sketch est conçu pour fonctionner avec WhiteCat Lighting Board
pour cartes arduino JEENODE sous logiciel ARDUINO 1.63
Ces cartes travaillent en radio fréquence.

Ce script permet de recevoir dans le jeenode les datas émis par 
whitecat depuis un jeelink sur le réseau jeenode 212.
il retransmet un tableau de 8 données, en bus i2C vers une arduino.
il n'écrit pas sur les ports jeenode.
une led témoin est branchée sur le port P3D pour monitorer l'envoi de data

Petite particularité, les digitales sont utilisées ainsi:
Wcat 2= P1_D
Wcat 3= P1_A
Wcat 4= P2_D
Wcat 5= P2_A
Wcat 6= P3_D
Wcat 7= P3_A
Wcat 8= P4_D
Wcat 9= P4_A

La librairie comprend en effet un reroutage des pins, de façon 
à ne pas perdre le temps avec n tableau de correspondances.

télécharger whitecat: http://www.le-chat-noir-numerique.fr
forum: http://www.le-chat-noir-numerique.fr/forums
cartes jeenodes: http://jeelabs.com/

jeenode SCL vers A5
jeenode SDA vers A4
*/
#include <JeeLib.h>
#include <SoftPWM.h>
#include <WhiteCat_lib.h>

#include <Wire.h>

WhiteCat Wcat;

#define MAX_SENT_BYTES 8//nombre de données envoyées en i2C= digital
char i2c_data[MAX_SENT_BYTES];

void setup() 
{
  
    Wcat.set_jeenode_id(2);//l'identifiant du/des récepteurs doit être différent
    Wcat.set_jeenode_frequency(RF12_868MHZ);//la bande utilisée doit être la même
    Wcat.set_jeenode_group(212);//le groupe doit être le même
  
    Wcat.set_receive_jeenode(On);//doit être activé AVANT Init_Com
    
    Wcat.set_io_mode(Jeenode_P3_D,Output);
    Wcat.Init_Com(14400,13,5);//init du jeenode inside
    
    Wire.begin();        // join i2c bus (address optional for master)
   
}

void loop() 
{
   Wcat.jeenode_receive_data();
  
  for(int i=0;i<MAX_SENT_BYTES;i++)
  {
  i2c_data[i]=rf12_data[i];
  }


  Wire.beginTransmission(4);
  Wire.write(i2c_data,MAX_SENT_BYTES); 
  Wire.endTransmission();
}

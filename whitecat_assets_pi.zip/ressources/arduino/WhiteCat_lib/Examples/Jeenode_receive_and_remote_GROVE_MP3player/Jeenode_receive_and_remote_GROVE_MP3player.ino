/*Dernière mise à jour: 2 juin 2015, par Christoph Guillermet

Ce sketch est conçu pour fonctionner avec WhiteCat Lighting Board
pour carte arduino sous logiciel ARDUINO 1.63

Ce sketch permet de recevoir les données envoyées par un Jeelink branché à Whitecat.
Il pilote le lecteur audio Grove MP3 en softserial.
Il faut brancher le fil jaune du lecteur en P1 D, le fil blanc en P2 D, le moins et le plus.

Une led, en P3 D s'allume pour montrer que la lecture en enclenchée, et que l'on reçoit bien 
le signal depuis le jeelink.

Eviter de brancher des petites enceintes, qui pourraient demander trop de puissance,
et bloquer le Grove MP3. Il faudra amplifier électroniquement le signal.

télécharger whitecat: http://www.le-chat-noir-numerique.fr
forum: http://www.le-chat-noir-numerique.fr/forums

Sketch créé à partir du Grove_Box, code Scott C,
Website: http://arduinobasics.blogspot.com/p/arduino-basics-projects-page.html
Documentation du chipset WT5001.pdf http://www.microelectronicos.com/datasheets/WT5001.pdf
*/

/*adresses à changer, coordonnées dans le tableau Jeelink. Dans whitecat le canal 0
correspond à la pin 2, le canal 1 à la pin 3 etc etc...*/
//le mode loop n'est pas mis, il est un petit peu capricieux pour un pilotage précis.

#define canal_play 0 //fait un play depuis le départ du fichier, à 0 fera un stop et recalage du fichier
#define canal_file 1 //20 fichiers max sur la carte SD, en MP3
#define canal_volume 2 // il y a 31 pas de volume en réel
#define canal_pause 3 //flasher un circuit pour pauser / dépauser la lecture


//routage jeenode
#define Jee_P1_D 4
#define Jee_P1_A 14
#define Jee_P2_D 5
#define Jee_P2_A 15
#define Jee_P3_D 6
#define Jee_P3_A 16
#define Jee_P4_D 7
#define Jee_P4_A 17

#define led_temoin_play Jee_P3_D

#define play_once 0x00
#define play_loop 0x01
#define play_all_loop 0X02
#define play_random 0X03

#include <JeeLib.h>

byte previous_rf12_data[60];

#include <SoftwareSerial.h>
SoftwareSerial mp3(Jee_P1_D, Jee_P2_D);//modify this with the connector you are using.
//TX RX Fil jaune du Grove Mp3 sur D1, fil blanc sur D2
//noir sur le gnd, et rouge sur le pwr

byte mp3Vol = 0;
byte mp3File=1;
byte mp3PreviousFile=1;
bool pause=0;

void setup () {
        
        mp3.begin(9600);
	delay(100);
        setPlayMode(play_once);      
        pinMode(led_temoin_play,OUTPUT);//monitoring led pour visualiser le play et la réception data
        //adresse du jeenode 
        rf12_initialize(2, RF12_868MHZ, 212);
}

void loop () 
{
 if (rf12_recvDone() && rf12_crc == 0)
 {
  mp3Vol = map( rf12_data[canal_volume], 0, 255, 0,31); 
  setVolume(mp3Vol);
  mp3File= map( rf12_data[canal_file], 0, 255, 1,19);
  
  //play stop//////////////////////////////////////////////////////
  if(  rf12_data[canal_play]>=64 && previous_rf12_data[canal_play]<64)
  {
  digitalWrite(led_temoin_play,OUTPUT);//monitoring led,HIGH);
  playSong(00,mp3File); 
  }
  if ( rf12_data[canal_play]<64 && previous_rf12_data[canal_play]>=64 )
  { 
  digitalWrite(led_temoin_play,LOW); 
  stopSong();
  }
  
  //pause / play / pause  impulsion en flashant le circuit dédié à la pause
  if((  rf12_data[canal_pause]>64 && previous_rf12_data[canal_pause]<=64) 
  ||(  rf12_data[canal_pause]<=64 && previous_rf12_data[canal_pause]>64) )
  {
    pause=1-pause;  
    if(pause==1) {pauseSong();}
  }
  
  //CHANGEMENT DE FICHIERS PENDANT UNE LECTURE
  if (mp3File != mp3PreviousFile && rf12_data[canal_play]>64)//playing
  {
  stopSong(); 
  delay(100);
  playSong(00,mp3File); 
  mp3PreviousFile=mp3File;
  }
  

  
  for(int i=0;i<rf12_len;i++)
  {  previous_rf12_data[i]=rf12_data[i];}
  
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
// writeToMP3: is a generic function that aims to simplify all of the methods that control the Grove MP3 Player

void writeToMP3(byte MsgLEN, byte A, byte B, byte C, byte D, byte E, byte F){
  byte codeMsg[] = {MsgLEN, A,B,C,D,E,F};
  mp3.write(0x7E);                        //Start Code for every command = 0x7E
  for(byte i = 0; i<MsgLEN+1; i++){
    mp3.write(codeMsg[i]);                //Send the rest of the command to the GROVE MP3 player
  }
}


/* The Following functions control the Grove MP3 Player : see datasheet for additional functions--------------------------------------------*/

void setPlayMode(byte playMode){
  /* playMode options:
        0x00 = Single song - played only once ie. not repeated.  (default)
        0x01 = Single song - cycled ie. repeats over and over.
        0x02 = All songs - cycled 
        0x03 = play songs randomly                                           */
        
  writeToMP3(0x03, 0xA9, playMode, 0x7E, 0x00, 0x00, 0x00);  
}


void playSong(byte songHbyte, byte songLbyte){                              // Plays the selected song
  writeToMP3(0x04, 0xA0, songHbyte, songLbyte, 0x7E, 0x00, 0x00);            
}


void pauseSong(){                                                           // Pauses the current song
  writeToMP3(0x02, 0xA3, 0x7E, 0x00, 0x00, 0x00, 0x00);
}


void stopSong(){                                                            // Stops the current song
  writeToMP3(0x02, 0xA4, 0x7E, 0x00, 0x00, 0x00, 0x00);
}


void playNextSong(){                                                        // Play the next song
  writeToMP3(0x02, 0xA5, 0x7E, 0x00, 0x00, 0x00, 0x00);
}


void playPreviousSong(){                                                    // Play the previous song
  writeToMP3(0x02, 0xA6, 0x7E, 0x00, 0x00, 0x00, 0x00);
}


void addSongToPlayList(byte songHbyte, byte songLbyte){
  //Repeat this function for every song you wish to stack onto the playlist (max = 10 songs)
  writeToMP3(0x04, 0xA8, songHbyte, songLbyte, 0x7E, 0x00, 0x00);
}


void setVolume(byte Volume){                                                // Set the volume
  byte tempVol = constrain(Volume, 0, 31);
  //Volume range = 00 (muted) to 31 (max volume)
  writeToMP3(0x03, 0xA7, tempVol, 0x7E, 0x00, 0x00, 0x00); 
}



/* The following functions retrieve information from the Grove MP3 player : see data sheet for additional functions--------------*/

// getData: is a generic function to simplifly the other functions for retieving information from the Grove Serial MP3 player
byte getData(byte queryVal, int dataPosition){
  byte returnVal = 0x00;
  writeToMP3(0x02, queryVal, 0x7E, 0x00, 0x00, 0x00, 0x00);
  delay(50);
  for(int x = 0; x<dataPosition; x++){
    if(mp3.available()){
      returnVal = mp3.read();
      delay(50);
    }
  }
  return(returnVal);
}

byte getVolume(){                                              //Get the volume of the Grove Serial MP3 player
  //returns value from 0 - 31
  return(getData(0xC1, 4));
}

byte getPlayingState(){                                        //Get the playing state : Play / Stopped / Paused
  //returns 1: Play,   2: Stop,   3:Paused
  return(getData(0xC2, 2));
}

byte getNumberOfFiles(){                                      //Find out how many songs are on the SD card
  //returns the number of MP3 files on SD card
  return(getData(0xC4, 3));
}
    

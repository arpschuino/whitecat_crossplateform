/*Dernière mise à jour: 27 avril 2015, par Christoph Guillermet

Ce sketch est conçu pour fonctionner avec WhiteCat Lighting Board
pour carte arduino sous logiciel ARDUINO 1.63

Il montre comment configurer l'arduino pour recevoir des données
des entrées analogiques, les filtrer et les remanipuler avant de 
les envoyer à whitecat.
Attention, il faut avoir décommenté la librairie (fichiers Whitecat_lib.cpp et Whitecat_lib.h
pour que les fonctions de dampering fonctionnent !

Avant de lire ce code, regarder le script Analog_in_dampered.ino.


Ce script permet d'utiliser un potentiomètre en A0 et  un 
bouton branché en Pin 8.
En appuyant sur le bouton vous activez le filtrage de A0, 
de brut en damperisé.

La configuration dans CFG MENU / Arduino et la fonction Wcat.Init_Com 
doivent correspondre: 
-Baudrate
-Last I/O
_Last Analog


télécharger whitecat: http://www.le-chat-noir-numerique.fr
forum: http://www.le-chat-noir-numerique.fr/forums
*/
#include <JeeLib.h>
#include <SoftPWM.h>
#include <WhiteCat_lib.h>

WhiteCat Wcat;


/////////////////////////////////////////////////////////////////
void setup()
{  
Wcat.Init_Com(14400,13,5);

//Input bouton Pin 8
Wcat.set_io_mode(8,Input);


Wcat.set_min_max(0,100,630);//AnalogNumber, Min, Max
Wcat.do_resample_for_analog_input(0,On);//AnalogNumber, OnOff
Wcat.resample_params(0,20,1);//Analog Number, Nb Samples, Threshold d
//Damper sur l'entrée analogue 0
Wcat.do_damper_for_analog_input(0,On);//AnalogNumber, OnOff
Wcat.damper_params(0,0.6,Off,0);//AnalogNumber, DamperFactor, BlockingMode, DamperingMode

}

/////////////////////////////////////////////////////////////////
void loop()
{

Wcat.serial_receive_and_do_orders();

int data_in_raw=Wcat.get_analog_input_raw_state(0);
int data_in_damperise=Wcat.get_analog_input_state(0);

if(Wcat.get_digital_input_state(8)==1)//appuyé envoi du data damperisé
  {
  Wcat.set_analog_input_state(1,data_in_damperise);
  }
  else //non appuyé: le data brut
  {
  Wcat.set_analog_input_state(1,data_in_raw);
  }

Wcat.send_data_to_whitecat();
}




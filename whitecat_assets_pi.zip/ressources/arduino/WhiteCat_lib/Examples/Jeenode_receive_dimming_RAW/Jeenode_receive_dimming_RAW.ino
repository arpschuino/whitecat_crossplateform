/*Dernière mise à jour: 5 mai 2015, par Christoph Guillermet

Ce sketch est conçu pour fonctionner avec WhiteCat Lighting Board
pour cartes arduino JEENODE sous logiciel ARDUINO 1.63
Ces cartes travaillent en radio fréquence.

Ce script permet de recevoir dans le jeenode les datas émis par 
whitecat depuis un jeelink sur le réseau jeenode 212.
Avec ce script vous pilotez en softPWM les 8 ports en output du jeenode.

Petite particularité, les digitales sont utilisées ainsi:
Wcat 2= P1_D
Wcat 3= P1_A
Wcat 4= P2_D
Wcat 5= P2_A
Wcat 6= P3_D
Wcat 7= P3_A
Wcat 8= P4_D
Wcat 9= P4_A

La librairie comprend en effet un reroutage des pins, de façon 
à ne pas perdre le temps avec n tableau de correspondances.

télécharger whitecat: http://www.le-chat-noir-numerique.fr
forum: http://www.le-chat-noir-numerique.fr/forums
cartes jeenodes: http://jeelabs.com/

*/
#include <JeeLib.h>
#include <SoftPWM.h>



void setup () {
  
rf12_initialize(2,RF12_868MHZ, 212);//initialisation jeenode
SoftPWMBegin();


pinMode(4,OUTPUT);
pinMode(14,OUTPUT);
pinMode(5,OUTPUT);
pinMode(15,OUTPUT);
pinMode(6,OUTPUT);
pinMode(16,OUTPUT);
pinMode(7,OUTPUT);
pinMode(17,OUTPUT);

  }

void loop () 
{
 
  if (rf12_recvDone() && rf12_crc == 0)
    {
    int jee_id=0;
        for(int i=0;i<13;i++)
        {
         
            switch (i)
            {
            case 0:
                jee_id=4;//Jee_P4_D
                SoftPWMSet(jee_id,rf12_data[i]-1);//}
            break;
            case 1:
                jee_id=14;//Jee_P1_A
                SoftPWMSet(jee_id,rf12_data[i]-1);//}
            break;
            case 2:
                jee_id=5;//Jee_P2_D VRAI PWM
                analogWrite(jee_id,rf12_data[i]-1);
            break;
            case 3:
                jee_id=15;//Jee_P2_A
                SoftPWMSet(jee_id,rf12_data[i]-1);//}
            break;
            case 4:
                jee_id=6;//Jee_P3_D VRAI PWM
                analogWrite(jee_id,rf12_data[i]-1);
            break;
            case 5:
                jee_id=16;//Jee_P3_A
                SoftPWMSet(jee_id,rf12_data[i]-1);//}
            break;
            case 6:
                jee_id=7;//Jee_P4_D
                SoftPWMSet(jee_id,rf12_data[i]-1);//}
            break;
            case 7:
                jee_id=17;//Jee_P4_A
                SoftPWMSet(jee_id,rf12_data[i]-1);//}
            break;
            default:
            break;
            }
          

            }

        
    }
}

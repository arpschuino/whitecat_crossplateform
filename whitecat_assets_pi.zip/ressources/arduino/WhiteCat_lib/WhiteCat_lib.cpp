/************************************************************************************************************
 WhiteCat_lib.h - librairie de communication s�rie arduino avec le logiciel WhiteCat http://le-chat-noir-numerique.fr
 MAJ 24/06/2015
 This library only works from version 0.8.7, with Arduino 1.6.5
 christoph guillermet / karistouf@yahoo.fr /
 ************************************************************************************************************/



#include <WhiteCat_lib.h>
#include <JeeLib.h>
#include <SoftPWM.h>


//chaine des ordres venant de whitecat
//un train de 127 data max (on off + analog) + 3 pour identifiant WhiteCat
#define maxLength 127+3
String inString = String(maxLength);

//jeenode analogues ports
Port Port_1(1);
Port Port_2(2);
Port Port_3(3);
Port Port_4(4);
/////////////////////////////////////////////////////////////////////
WhiteCat::WhiteCat()
{
_Baudrate=14400;
_Nbr_Digital=13;
_Nbr_Analog=6;
}
/////////////////////////////////////////////////////////////////////
void WhiteCat::Init_Com(int Baudrate, int Nbr_Digital, int Nbr_Analog)
{

_Baudrate=Baudrate;

if(Nbr_Digital<MAX_Nbr__Digital)
{
_Nbr_Digital=Nbr_Digital+1;
}
else {_Nbr_Digital=MAX_Nbr__Digital;}

if(Nbr_Analog<MAX_Nbr__Analog)
{
_Nbr_Analog=Nbr_Analog+1;
}
else{_Nbr_Analog=MAX_Nbr__Analog;}

Serial.begin(_Baudrate);
inString = "";// remet le buffer � 0

//INITIALISATION DES ON/OFF sur la carte en INPUT par d�faut
/*if(_allow_pin_writing==1 )
{
for(int i=2; i<_Nbr_Digital; i++)
{
   pinMode(i,INPUT);
}
}*/
//initialisation des tableaux pour �viter caractere NULL
for(int i=0;i<MAX_Nbr__Digital;i++)
{
 _buffer_state_dig[i]=0;
 _buffer_to_send[i]=32;
 _buffer_to_send[i+MAX_Nbr__Analog]=1;
 _buffer_received[i]=1;
 _buffer_to_send[i+MAX_Nbr__Analog]=1;
}

if(_use_jeenode_send==1 || _use_jeenode_receive==1)
{
rf12_initialize(_jeenode_id, _jeenode_frequency, _jeenode_group);//initialisation jeenode
if(_use_jeenode_receive==1) {SoftPWMBegin();}
}
}


///////////////////////////////////////////////////////////////////

void WhiteCat::set_io_mode(int Pin, bool mode)
{
_digital_is_output[Pin]=mode;
int pPin=0;
switch(_i_m_a_jeenode)
{

    case 0://Arduino classic
        switch(mode)
        {
        case 0:
        pinMode(Pin,INPUT);
        break;
        case 1:
        pinMode(Pin,OUTPUT);
        break;
        }
    break;

    case 1:
        switch(Pin)
        {
        case 0:
            pPin=Jee_P1_D;
        break;
        case 1:
            pPin=Jee_P1_A;
        break;
        case 2:
            pPin=Jee_P2_D;
        break;
        case 3:
            pPin=Jee_P2_A;
        break;
        case 4:
            pPin=Jee_P3_D;
        break;
        case 5:
            pPin=Jee_P3_A;
        break;
        case 6:
            pPin=Jee_P4_D;
        break;
        case 7:
            pPin=Jee_P4_A;
        break;
        default:
            //pPin=_Nbr_Digital+_Nbr_Analog+1;
        break;
        }
        switch(mode)
        {
            case 0: pinMode(pPin,INPUT);
            break;
            case 1: pinMode(pPin,OUTPUT);
            break;
        }
    break;
}
/*
if(pPin<_Nbr_Digital+_Nbr_Analog)
{
_digital_is_output[pPin]=mode;
switch(_digital_is_output[pPin])
    {
     case 0: pinMode(pPin,INPUT);
     break;
     case 1: pinMode(pPin,OUTPUT);
     break;
    }
}*/
}


void WhiteCat::set_arduino_pin_writing(bool mode)
{
    _allow_pin_writing=mode;
}



void WhiteCat::set_pwm(int Pin, bool mode)
{
if(Pin<_Nbr_Digital+_Nbr_Analog+1)
{ _allow_pwm_write[Pin]=mode; }
}

/*
void WhiteCat::do_damper_for_analog_input(int ord,bool mode)
{
if(ord>=0 && ord<_Nbr_Analog)
{
_do_damper_analog_input[ord]=mode;
}
}
*/

bool WhiteCat::get_digital_input_state(int ord)
{
bool state;
if(ord>=0 && ord<_Nbr_Digital)
{
state=_buffer_state_dig[ord];
}
return(state);
}


void WhiteCat::set_digital_input_state(int ord, bool state)
{
if(ord>=0 && ord<_Nbr_Digital)
{
_buffer_state_dig[ord]=state;
switch(state)
{
  case 0:
      _buffer_to_send[ord]=32;//avoiding NULL character
  break;
  case 1:
    _buffer_to_send[ord]=127;
  break;
}

}
}

/*
int WhiteCat::get_analog_input_state(int ord)
{
int state;
if(ord<_Nbr_Analog)
{
state=_buffer_analog[ord];
}
return(state);
}*/

int WhiteCat::get_analog_input_raw_state(int ord)
{
int state;
if(ord<_Nbr_Analog)
{
state=byte(_raw_data[ord]/4);
}
return(state);
}

void WhiteCat::set_analog_input_state(int ord,int state)
{
if(ord<_Nbr_Analog )
{
if(state<1){state=1;}
if(state>255){state=255;}
_buffer_analog[ord]=state;
_buffer_to_send[_Nbr_Digital+ord-1]=state;
}
}


int WhiteCat::_read_analog(int Pin)
{
int val=0;
switch (_reading_analog_from_jeenode)
{
    case 0://normal arduino where array coordonates are analogRead(0);
    val=analogRead(Pin);
    break;
    case 1://jeenode and rempapping pins needed

           switch (Pin)
           {
           case 0:
               val=analogRead(Jee_P1_A);
           break;
           case 1:
               val=analogRead(Jee_P2_A);
           break;
           case 2:
                val=analogRead(Jee_P3_A);
           break;
           case 3:
                val=analogRead(Jee_P4_A);
           break;
           default:
           break;
           }
    break;
}

return(val);
}


boolean WhiteCat::_read_digital(int Pin)
{

bool val=0;
switch (_reading_digital_from_jeenode)
{
    case 0://normal arduino where array coordonates are analogRead(0);
    val=digitalRead(Pin);
    break;
    case 1://jeenode and rempapping pins needed
           switch (Pin)
           {
           case 0:
               val=digitalRead(Jee_P1_D);
           break;
           case 1:
               val=digitalRead(Jee_P2_D);
           break;
           case 2:
                val=digitalRead(Jee_P3_D);
           break;
           case 3:
                val=digitalRead(Jee_P4_D);
           break;
           default:
               val=0;
           break;
           }

    break;
}
    return(val);
}

//received data from whitecat, array accessible outside for other procs
int WhiteCat::buffer_state_to_send(int ord)
{
    return(_buffer_received[ord]);
}

int WhiteCat::buffer_size_to_send()
{
    return(_Nbr_Digital+_Nbr_Analog+3);
}

////////////////////RESAMPLE/////////////////////////////////////
/*
void WhiteCat::set_min_max(int ord, int min_data, int max_data)
{
if(min_data<0) min_data=0;
if(max_data>1023) max_data=1023;
if(ord>=0 && ord<_Nbr_Analog)
{
_pied[ord]=min_data;
_maxi[ord]=max_data;
}
}

void WhiteCat::do_resample_for_analog_input(int ord,bool mode)
{
if(ord>=0 && ord<_Nbr_Analog)
{
_do_resample_analog_input[ord]=mode;
}
}


void WhiteCat::resample_params(int ord,int resample_rate,int tolerance)
{
_samples[ord]=resample_rate;
_tol[ord]=tolerance;
}
*/
///////////////////////DAMPER//////////////////////////////////////
/*
void WhiteCat::damper_params(int ord,float decay_fac,boolean mode, int type)
{
_damper_vel[ord] = 0.1;
_damper_dt = 0.1;
_damper_decay_constant[ord]=decay_fac;
_damper_blocking_mode[ord]=mode;
_damper_mode[ord]=type;
}
*/
void WhiteCat::_read_inputs_on_pins()
{

        for(int i=0;i<(_Nbr_Digital+_Nbr_Analog);i++)
            {
            _buffer_to_send[i]=1;//eviter le caractere NULL
            }

        bool temp_bool=0;
        int temp_val=0;
        int result=0;
        int starting_index=0;

        switch(_reading_digital_from_jeenode)
        {
        case 0://arduino classical where rx and tx are not used , pos 0 and 1
            starting_index=2;
        break;
        case 1:
            starting_index=0;//for jeenode arrays
        break;
        }


            for(int i=starting_index;i<_Nbr_Digital;i++)//i=2 because of tx rx
            {
                if(_digital_is_output[i]==0 && _allow_pwm_write[i]==0 )
                    {
                    temp_bool=WhiteCat::_read_digital(i);
                    _buffer_state_dig[i]=temp_bool;
                    if(temp_bool==0){ _buffer_to_send[i]= 32;}
                    else {_buffer_to_send[i]= 127;}
                    }
            }

            for(int i=0;i<_Nbr_Analog;i++)
            {
            _raw=WhiteCat::_read_analog(i);
     /*      _data_val[i]=_raw;*/
            _raw_data[i]=_raw;//to access to raw data if filtered

            //raw data stockage
            result=_raw/4;
            if(result<1) result=1;
            _buffer_to_send[i+_Nbr_Digital-1]=(byte)(result);
            _buffer_analog[i]=(byte)(result);


             //RESAMPLING
             /*
            if(_do_resample_analog_input[i]==1)
                    {
                        _index=0;
                        _sum=0;
                        for (int i=0; i<_samples[i]; i++)
                        {
                        _raw=WhiteCat::_read_analog(i);
                        if(   _raw > (_previous_raw+((_previous_raw/100)*_tol[i]))
                        || _raw < (_previous_raw+((_previous_raw/100)*_tol[i])) )
                        {
                        _sum=_sum+_raw;
                        _index++;
                        }
                        }
                        _data_val[i]=_sum/_index;
                        if(_data_val[i]<_pied[i]) _data_val[i]=_pied[i];
                        else if(_data_val[i]>_maxi[i]) _data_val[i]=_maxi[i];
                        //result apart
                        result=map(_data_val[i],_pied[i],_maxi[i],0,255);
                        if(result<1){result=1;}
                        _buffer_to_send[i+_Nbr_Digital-1]=(byte)(result);
                        _buffer_analog[i]=(byte)(result);
                     }

            //DAMPING
            if(_do_damper_analog_input[i]==1)
                   {
                        _damper_previous_target[i]=_damper_target_val[i];

                        float tmp=map(_data_val[i],_pied[i],_maxi[i],0,255);
                        _damper_target_val[i]=tmp/255;


                      switch(_damper_blocking_mode[i])
                        {
                        case 0:
                        _damper_do_calculation[i]=1;
                        break;
                        case 1://no change of data = no calculation
                        _damper_do_calculation[i]=0;
                        if(tmp!=_damper_previous_target[i]) {_damper_do_calculation[i]=1;}
                        break;
                        }

                    if(_damper_do_calculation[i]==1)
                   {
                        switch (_damper_mode[i])
                        {
                        case 1://elastic effect
                        _damper_accel[i] = (_damper_target_val[i] - _damper_val[i]) * 1 - _damper_vel[i] *  _damper_decay_constant[i];
                        _damper_vel[i] += _damper_accel[i] * _damper_dt;
                        _damper_val[i] += _damper_vel[i] * _damper_dt;
                        break;
                        case 2:
                        _damper_vel[i] = (_damper_target_val[i] - _damper_val[i]) * _damper_decay_constant[i];
                        _damper_val[i] += _damper_vel[i] * _damper_dt;
                        break;
                        default://in out egaux
                        _damper_vel[i]= (_damper_target_val[i]-_damper_val[i])* _damper_decay_constant[i];
                        _damper_val[i]+=(_damper_vel[i]*_damper_dt)* _damper_decay_constant[i];
                        break;
                        }

                        if(_damper_val[i]<0.0){_damper_val[i]=0.0; _damper_do_calculation[i]=0;}
                        else if(_damper_val[i]>1.0){_damper_val[i]=1.0; _damper_do_calculation[i]=0;}
                        }
                        _dampered_data[i]=_damper_val[i]*255;
                        if( _dampered_data[i]<1){ _dampered_data[i]=1;}
                        if( _dampered_data[i]>255){ _dampered_data[i]=255;}
                        _buffer_to_send[i+_Nbr_Digital-1]=_dampered_data[i];
                        _buffer_analog[i]=_dampered_data[i];
                    }
                */

            }

}

////////////////////////////////////////////////////////////////
void WhiteCat::serial_receive_and_do_orders()
{
  while(Serial.available() > 0)
    {
    char inChar=Serial.read(); // lire caractere
    //si l'entr�e n est pas un caractere null de fin d ordre
    if(inChar!='\0')//si pas de caractere NULL terminant la chaine  d'envoi
    {
        if (inString.length() <maxLength)
        { inString+=inChar;}
     else
        { inString =""; }
    }
    // un caractere nul marque la fin d'un ordre...
    else
    {
        if (inString.length() >= 3)// re�u 0, fin d'un ordre, on d�code
        {


        //begin read order

        // les trois premiers caract�res d�terminent l'ordre...
        String WCcde = inString.substring(0,3);    // commande whitecat


        if (WCcde == "SD/")
        {

            WhiteCat::_read_inputs_on_pins();

            _DO_SEND_DATA_TO_WHITECAT=1;
        }


        if(WCcde == "DO/")
        {
         for(int i=2; i<_Nbr_Digital; i++)//2 because TX RX
            {
            if(_allow_pin_writing==1 && _digital_is_output[i]==1)
            {
                switch(_allow_pwm_write[i])
                        {
                        case 0://on off
                        if(inString[i+3]<64)
                        {digitalWrite(i,LOW);}
                        else {digitalWrite(i,HIGH);}
                        break;
                        case 1://PWM
                        _valeur_pwm[i]=byte(inString[i+3]);
                        analogWrite(i,_valeur_pwm[i]-1);//-1 because 0 is NULL
                        break;
                        }
            }
            _buffer_received[i]=inString[i+3];//from whitecat to use with jeenode or any other protocol like i2C to get data
            }

        }



      else if(WCcde != "DO/" && WCcde !="SD/")
      {inString="";}//nettoyage de la chaine d'ordre

      //end of read order
        inString = "";
        break;
        }
      else
        {  inString = "";  }

      }
  }

}

void WhiteCat::send_data_to_whitecat()
{
if( _DO_SEND_DATA_TO_WHITECAT==1)
{
int size_of_buf=_Nbr_Digital+_Nbr_Analog;
            Serial.print("WC/");
            Serial.write(_buffer_to_send,size_of_buf);
            Serial.println("");
_DO_SEND_DATA_TO_WHITECAT=0;
}
}

////////////////////////JEENODE/////////////////////////////

void WhiteCat::send_data_to_jeelink()
{
int size_of_buf=_Nbr_Digital+_Nbr_Analog;
rf12_sendNow(0, &_buffer_to_send,size_of_buf);
}

void WhiteCat::set_send_jeenode(bool mode)
{
 _use_jeenode_send=mode;
}

void WhiteCat::jeelink_receive_data_from_jeenode()
{
if (rf12_recvDone() && rf12_crc == 0)
    {

    for(int i=0;i<_Nbr_Digital+_Nbr_Analog;i++)
    {
    _data_from_jeenode[i]=rf12_data[i];
    }
    }
}

/*
void WhiteCat::jeelink_receive_data_from_specific_jeenode(int ExpectedID)
{
//structure sauvegarde data
byte saveHdr, saveLen, saveData[RF12_MAXDATA];
word saveCrc;

if (rf12_recvDone() && rf12_crc == 0)
    {

         // quickly save a copy of all volatile data
    saveLen = rf12_len;
    saveCrc = rf12_crc;
    saveHdr = rf12_hdr;
    memcpy(saveData, (const void*) rf12_data, sizeof saveData);
    rf12_recvDone(); // release lock on info for next reception

    int SenderID = (RF12_HDR_MASK & saveHdr);
    if(SenderID==ExpectedID)
    {
        for(int i=0;i<_Nbr_Digital+_Nbr_Analog;i++)
        {
        _data_from_jeenode[i]=saveData[i];
        }
    }
    }
}*/


int WhiteCat::jeelink_get_received_analog_data(int ord)
{
int data=_data_from_jeenode[_Nbr_Digital+ord-1];
return(data);
}

void WhiteCat::jeelink_get_all_received_analog_data()
{
for(int i=0;i<_Nbr_Analog;i++)
    {
    _buffer_analog[i]=_data_from_jeenode[_Nbr_Digital+i-1];
    _buffer_to_send[_Nbr_Digital+i-1]= _buffer_analog[i];
    }
}



int WhiteCat::jeelink_get_received_digital_data(int ord)
{
int data=_data_from_jeenode[ord];
return(data);
}

void WhiteCat::jeelink_get_all_received_digital_data()
{
_buffer_to_send[0]=1;
_buffer_to_send[1]=1;
for(int i=0;i<_Nbr_Digital;i++)
    {
    _buffer_digital[i]=_data_from_jeenode[i];
    _buffer_to_send[i+2]= _data_from_jeenode[i];//+2 =tx rx
    }
}

void WhiteCat::set_i_m_a_jeenode(bool mode)
{
    _i_m_a_jeenode=mode;
}

void WhiteCat::set_jeenode_read_analog_input(bool mode)
{
   _reading_analog_from_jeenode=mode;
}

void WhiteCat::set_jeenode_read_digital_input(bool mode)
{
   _reading_digital_from_jeenode=mode;
}


void WhiteCat::set_receive_jeenode(bool mode)
{
 _use_jeenode_receive=mode;
}


void WhiteCat::set_jeenode_id(int id)
{
if(id>0 && id<31)
{_jeenode_id=id;}
}

void WhiteCat::set_jeenode_frequency(int mode)
{
switch (mode)
{
   case 1:
    _jeenode_frequency=RF12_433MHZ;
    break;
    case 3:
    _jeenode_frequency=RF12_915MHZ;
    break;
    default:
    _jeenode_frequency=RF12_868MHZ;
    break;
}
}

void WhiteCat::set_jeenode_group(int grp)
{
if(grp>0 && grp<=212)
{
_jeenode_group=grp;
}
}

void WhiteCat::jeelink_send_to_jeenode()//envoi du jeelink vers un jeenode
{
int size_of_array=WhiteCat::buffer_size_to_send();
byte tab[size_of_array];

for(int i=0;i<size_of_array;i++)
{
tab[i]=  WhiteCat::buffer_state_to_send(i+2);
}
rf12_sendNow(0, &tab, size_of_array);
}


void WhiteCat::jeenode_receive_data()
{
   if (rf12_recvDone() && rf12_crc == 0)
    {
    }
}
void WhiteCat::jeenode_receive_data_and_write_pins()
{

  if (rf12_recvDone() && rf12_crc == 0)
    {
    int jee_id=0;
    int val=0;
        for(int i=0;i<_Nbr_Digital+_Nbr_Analog;i++)
        {
        if(_digital_is_output[i]==1)
        {

        switch(_allow_pwm_write[i])
            {
            case 0://on off
                if(rf12_data[i]<64){val=0;}
                else {val=255;}
            break;
            case 1://PWM
                val=rf12_data[i]-1;
            break;
            }

         switch (i)
            {
            case 0:
                jee_id=4;//Jee_P4_D
                SoftPWMSet(jee_id,val);
            break;
            case 1:
                jee_id=14;//Jee_P1_A
                SoftPWMSet(jee_id,val);
            break;
            case 2:
                jee_id=5;//Jee_P2_D VRAI PWM
                analogWrite(jee_id,val);
            break;
            case 3:
                jee_id=15;//Jee_P2_A
                SoftPWMSet(jee_id,val);
            break;
            case 4:
                jee_id=6;//Jee_P3_D VRAI PWM
                analogWrite(jee_id,val);
            break;
            case 5:
                jee_id=16;//Jee_P3_A
                SoftPWMSet(jee_id,val);
            break;
            case 6:
                jee_id=7;//Jee_P4_D
                SoftPWMSet(jee_id,val);
            break;
            case 7:
                jee_id=17;//Jee_P4_A
                SoftPWMSet(jee_id,val);
            break;
            default:
            break;
            }
          }
        }
    }
}



//////////////////////////////////////////////////////////////////////////////////

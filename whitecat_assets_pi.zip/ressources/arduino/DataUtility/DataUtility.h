/************************************************************************************************************
 * DataUtility.h -
 Christoph Guillermet
 http://le-chat-noir-numerique.fr
 19/06/2015
 ************************************************************************************************************/

#ifndef DataUtility_h
#define DataUtility_h

# define  _nb_sample 10

class DataUtility {

public:

    DataUtility ();//classe initialisation

    void ConstrainInputRange(int low_val, int high_val);
    void ConstrainOutputDMX(int low_val, int high_val);
    void ConstrainOutputDifferenceDMX(int low_val, int high_val);
    void SetValue(int Val);//calculations
    byte GetDMXData();//final result in 1 byte
    int GetData();//constrained result
    int GetRawData();//raw result
    int GetAccelDifference();//give a global value of differences of the data
    byte GetAccelDMXDifference();//get difference in a byte range

    //monitoring functions on a LCD screen of 16 char
    char SetName(char name[16]);
    char* GetStringName();
    char* GetStringRawData();
    char* GetStringProcessedData();
    char* GetStringProcessedDMXData();
    char* GetStringDifferenceData();

  private:

    //values
    int _RawVal;
    int _LowVal;
    int _HighVal;
    int _ConstrainedVal;

    byte _DMXVal;
    byte _LowDMXVal;
    byte _HighDMXVal;
    byte _ConstrainedDMXVal;


    //difference between value, to get the acceleration
    byte _LowDifDMXVal;
    byte _HighDifDMXVal;
    int _AccelDifference;
    byte _AccelDMXDifference;
    int _previousConstrainedVal[_nb_sample];//a stack to calculate differences
    int _index_previousConstrainedVal;

    //monitoring purpose for LCD screen (16 chars)
    char _name[16];
    char _raw_infos[16];//range calibration and raw_data
    char _processed_infos[16];//result of process + DMX conversion
    char _difference_infos[16];//result of process + DMX conversion
    char _dmx_infos[16];//dmx output and dmx range

};


#endif

#include <Arduino.h>
#include <DataUtility.h>

DataUtility::DataUtility()//initialisation de la classe
{
    _LowVal=0;
    _HighVal=1024;
    _RawVal=0;
    _ConstrainedVal=0;
    _DMXVal=0;
    _LowDMXVal=0;
    _HighDMXVal=255;
    _index_previousConstrainedVal=0;
}


void DataUtility::ConstrainInputRange(int low_val, int high_val)
{
    _LowVal=low_val;
    _HighVal=high_val;
}



void DataUtility::ConstrainOutputDMX(int low_val, int high_val)
{
    _LowDMXVal=low_val;
    _HighDMXVal=high_val;
}



void DataUtility::ConstrainOutputDifferenceDMX(int low_val, int high_val)
{
    _LowDifDMXVal=low_val;
    _HighDifDMXVal=high_val;
}

//all calculation is done there
void DataUtility::SetValue(int Val)
{
    //stacking data
    _previousConstrainedVal[_index_previousConstrainedVal]=_ConstrainedVal;
    _index_previousConstrainedVal++;
    if(_index_previousConstrainedVal>_nb_sample){_index_previousConstrainedVal=0;}

    _RawVal=Val;
    if(_RawVal < _LowVal)
    {
        _ConstrainedVal=_LowVal;
    }
    else if(_HighVal < _RawVal)
    {
         _ConstrainedVal=_HighVal;
    }
    else
        _ConstrainedVal= _RawVal;

    float sum=0;
    for(int i=0;i<_nb_sample;i++)
    { sum+=  _previousConstrainedVal[i]; }
    _AccelDifference=(abs)(_ConstrainedVal-(int)(sum/_nb_sample));

    _DMXVal=map(_ConstrainedVal,_LowVal,_HighVal,_LowDMXVal,_HighDMXVal);
    _AccelDMXDifference=map(_AccelDifference,0,4000,_LowDifDMXVal,_HighDifDMXVal);



}


byte DataUtility::GetDMXData()
{
    return(_DMXVal);
}

int DataUtility::GetData()
{
    return(_ConstrainedVal);
}

int DataUtility::GetRawData()
{
    return(_RawVal);
}

int DataUtility::GetAccelDifference()
{
    return(_AccelDifference);
}


byte DataUtility::GetAccelDMXDifference()
{
    return(_AccelDMXDifference);
}


//MONITORING Utility for i2C LCD Screen with 1- char and 2 lines
char  DataUtility::SetName(char name[16])
{
    sprintf(_name,name);
}

char* DataUtility::GetStringName()
{
    return(_name);
}

char* DataUtility::GetStringRawData()
{
    sprintf(_raw_infos,"%d|%d|%d",_LowVal,_HighVal,_RawVal);
    return(_raw_infos);
}

char* DataUtility::GetStringProcessedData()
{
    sprintf(_processed_infos,"%d>%d",_ConstrainedVal,_DMXVal);
    return(_processed_infos);
}

char* DataUtility::GetStringDifferenceData()
{
    sprintf(_difference_infos,"%d>%d",_AccelDifference,_AccelDMXDifference);
    return (_difference_infos);
}

char* DataUtility::GetStringProcessedDMXData()
{
    sprintf(_dmx_infos,"%d|%d|%d",_LowDMXVal,_HighDMXVal,_ConstrainedDMXVal);
    return(_dmx_infos);
}


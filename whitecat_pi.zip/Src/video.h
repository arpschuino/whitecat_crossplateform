/*-------------------------------------------------------------------------------------------------------------
                                 |
          CWWWWWWWW              | Copyright (C) 2009-2013  Christoph Guillermet
       WWWWWWWWWWWWWWW           |
       WWWWWWWWWWWWWWW           |               2026       Jacques Bouault - arpschuino.fr
     WWWWWWWWWWWWWWWWWWW         | This file is part of White Cat.
    WWWWWWWWWWWWWWWWWCWWWW       |
   WWWWWWWWWWWWWWWWW tWWWWW      | White Cat is free software: you can redistribute it and/or modify
  WWWW   WWWWWWWWWW  tWWWWWW     | it under the terms of the GNU General Public License as published by
 WWWWWt              tWWWWWWa    | the Free Software Foundation, either version 2 of the License, or
 WWWWWW               WWWWWWW    | (at your option) any later version.
WWWWWWWW              WWWWWWW    |
WWWWWWWW               WWWWWWW   | White Cat is distributed in the hope that it will be useful,
WWWWWWW               WWWWWWWW   | but WITHOUT ANY WARRANTY; without even the implied warranty of
WWWWWWW      CWWW    W WWWWWWW   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
WWWWWWW            aW  WWWWWWW   | GNU General Public License for more details.
WWWWWWWW           C  WWWWWWWW   |
 WWWWWWWW            CWWWWWWW    | You should have received a copy of the GNU General Public License
 WWWWWWWWW          WWWWWWWWW    | along with White Cat.  If not, see <http://www.gnu.org/licenses/>.
  WWWWWWWWWWC    CWWWWWWWWWW     |
   WWWWWWWWWWWWWWWWWWWWWWWW      |
    WWWWWWWWWWWWWWWWWWWWWW       |
      WWWWWWWWWWWWWWWWWWa        |
        WWWWWWWWWWWWWWW          |
           WWWWWWWWt             |
                                 |
---------------------------------------------------------------------------------------------------------------*/

#pragma once

////////////////////////VIDEO //////////////////////////////////////////////////
extern double image_recording_size;
extern double image_recorded_size;
extern int fps_video_rate;
extern int default_fps_video_rate;
extern int recup_val_pix_video;
extern bool ocvfilter_is_on;
extern int ocv_calcul_mode;
extern char string_ocv_mode[8];
extern int threshold_level;
extern int erode_level;
extern int div_facteur;
extern char string_threshold_is[24];
extern char string_erode_is[24];
extern char string_blur_is[24];
extern char string_div_is[24];
extern int flip_image;
extern int threshold_on;
extern int erode_mode;
extern int blur_on;
extern double pixels_changed;
extern double old_pixels_changed;
extern double nbre_pixels_changed;
extern float ratio_pixels_changed;

extern int camera_size_settings_is;
extern int camera_size_array[2][2];
extern int camera_fps_settings_is;
extern bool manipulating_camera;

extern int camera_modes_and_settings[8][16];
extern float level_visu;
extern int index_count_trackers;
extern int frame_video_x, frame_video_y;
extern int video_size_x, video_size_y;
extern bool camera_is_on;
extern int camera_on_open;
extern int camera_original_fps_is;
extern float display_fps;
// 6 tracking docks // 12 espaces de tracking par tracking dock//
extern int tracking_coordonates[6][12][4];
extern bool tracking_contents[6][12][512];
extern int buffer_tracker[514];
extern int tracker_level[6][12];
extern int tracker_to_edit;
// smooth
extern float tracker_target_val[6][12];
extern float tracker_val[6][12];
extern float tracker_decay_constant;
extern float tracker_dt;
extern int index_decay_tracker;
extern bool edit_tracker;
extern bool move_tracker;
extern bool tracker_clearmode;
extern bool view_levels_tracker;
extern int videoX, videoY;
extern int default_videoX, default_videoY;
extern char string_tracker_edited_dat[48];
// tracking cam
// 6 tracking docks // 12 espaces de tracking par tracking dock//
extern int tracking_dock_selected;
extern bool tracking_spaces_on_off[6][12];

////////////////////VIDEO AVI///////////////////////////////////////////////////
extern char list_my_video[25][16];
extern char annote_my_video[25][64];
extern int nbre_de_videos;
